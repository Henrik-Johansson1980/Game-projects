﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitButtonScript : MonoBehaviour {

	//Quit the gam if button is pressed
	public void Quit()
	{
		//If app is playing in untiy editor
		#if UNITY_EDITOR
			UnityEditor.EditorApplication.isPlaying=false;
		#else //if application is running
		Application.Quit();
		#endif
	}
}
