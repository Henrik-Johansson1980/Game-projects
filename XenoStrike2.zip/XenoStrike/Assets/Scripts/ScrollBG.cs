﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Scroll the material on the object along the y-axis
public class ScrollBG : MonoBehaviour {

	public float scrollSpeed = 0.05f; 

	// Update is called once per frame
	void Update () {
		Material m = GetComponent<MeshRenderer>().material;
		Vector2 offset = m.mainTextureOffset;
		offset.y += Time.deltaTime * scrollSpeed;
		m.mainTextureOffset = offset;
	}
}
