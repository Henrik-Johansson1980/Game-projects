﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour {

	//Vector2's used as min and max values for a random range
	public Vector2 rotationMinMax =new Vector2(15,90); 
	public Vector2 driftMinMax = new Vector2(.25f,2);
	public float lifeTime = 5f; //Time in seconds that the powerUp stays in play
	public float fadeTime = 2f; //Time in seconds before it fades away

	public WeaponType type; //Type of weapon powerup
	public GameObject obj; //Reference to the powerup child
	public TextMesh letter; //Reference to the textmesh
	public Vector3 rotationsPerSecond; //Euler rotation speed
	public float birthTime;

	public Boundary boundary; //Screen edges

	void Awake()
	{
		//Find the cube/sphere
		obj = transform.Find("Cube").gameObject;
		//Find Textmesh
		letter = GetComponent<TextMesh>();

		//Randomize a vector 3 velocity
		Vector3 v = Random.onUnitSphere; // Get a random XYZ velocity
		//Reset z
		v.z = 0;
		//Make vector length to 1m
		v.Normalize(); 
		//Set the velocity length between driftmax values x and y
		v *= Random.Range(driftMinMax.x, driftMinMax.y);
		GetComponent<Rigidbody>().velocity = v;

		//Set object rotation
		transform.rotation = Quaternion.identity; //No rotation
		//Set rotations per second by randomizing values from the rotationMinMax vector2 components
		rotationsPerSecond = new Vector3 (
			Random.Range(rotationMinMax.x, rotationMinMax.y),
			Random.Range(rotationMinMax.x, rotationMinMax.y),
			Random.Range(rotationMinMax.x, rotationMinMax.y)
		);

		birthTime = Time.time; //Set birthtime
		InvokeRepeating("CheckOffScreen",0f,2f);
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		//Rotate
		obj.transform.rotation = Quaternion.Euler(rotationsPerSecond*Time.time);
		
		//Fade out over time
		float fadeTimer = (Time.time - (birthTime+lifeTime))/fadeTime;
		//if fadeTimer is equal to or larger than 1 dersroy this powerup
		if(fadeTimer >=1){
			Destroy(this.gameObject);
			return;
		}

		//fade out the powerup while the killTImer is between 0 and 1
		if(fadeTimer > 0 )
		{
			//Fade powerup color
			Color color = obj.GetComponent<Renderer>().material.color;
			color.a = 1f-fadeTimer;
			obj.GetComponent<Renderer>().material.color = color;
			//Fade letter color
			color = letter.color;
			color.a = 1f -(fadeTimer*0.5f);
			letter.color=color;
		}

	}

	//Check the transform.position.y and destroy this gameobject if out of bounds.
	void CheckOffScreen()
	{

		if ( this.transform.position.y < boundary.yMin  || 
			this.transform.position.y > boundary.yMax  ||
			this.transform.position.x < boundary.xMin  || 
			this.transform.position.x > boundary.xMax )
		{
			//Debug.Log(this.transform.position + " Out of bounds");
			Destroy(this.gameObject);
		}
	}

	//Sets the weapontype of powerup
	public void SetType(WeaponType wt)
	{
		//Get WeaponDefinition from main
		WeaponDefinition wDef = GameController.GetWeaponDefinition(wt);
		//Set color of powerup object
		obj.GetComponent<Renderer>().material.color = wDef.color;
		//Set powerup letter
		letter.text = wDef.pUpLetter;
		type = wt;
	}

	//Powerup is collected
	//function is called by playerclass when the powerup is collected (collision occurs)
	public void  CollectedBy(GameObject collector)
	{
		Destroy(this.gameObject);	
	}
}
