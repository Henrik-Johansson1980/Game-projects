﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Basic enemy that moves straight down on screen
// and fires bulets on the player
public class Enemy : MonoBehaviour {

	public float speed = 10f; //Speed along y
	public float fireRate = 0.3f; //Fire rate
	public float health = 10; //healthpoints
	public int score = 100; //score value
	public float powerupDropProbability = 1f;
	public float screenTopEdge = 45f; //used to negate damage on enemy while its above this y.pos
	public Boundary boundary; //Bounds
	public int damageFrames = 2; //Number of frames to show damage
	public int framesRemaining; //No of damageframes left
	public Color[] originalColors; //The original colors of the materials of this enemy
	public Material[] materials; //Material of this enemy and its children
	protected bool powerUpTriggered = false; //Prevents spawning of multiple powerups?
	public Transform[] guns; //Array of guns
	public GameObject enemyProjectilePrefab;  //Enemy bullet prefab
	public GameObject explosion; //Explosion particle system to trigger when defeated
	 

	//Property, a method that acts as a field used to get/set the enemyposition 
	public Vector3 pos
	{
		get {
			return (this.transform.position);
		}

		set{
			this.transform.position = value;
		}
	}

	//Call the enemy's CheckoffScreen function to destroy the gameobject if it is out of bounds
	//and gets the materials from prefab
	void Awake(){

		InvokeRepeating("CheckOffScreen",0f,2f);

		//Get materials of this enemy to be used to reset its original color after a hit
		materials = GetAllMaterials(this.gameObject);
		originalColors = new Color[materials.Length];
		for(int i = 0; i < materials.Length; i++)
		{
			originalColors[i] = materials[i].color;	
		}
	}

	//Init
	void Start()
	{
		//Call fire function repeatedly
		InvokeRepeating ("Fire", fireRate, fireRate);
	}

	// Update is called once per frame
	void Update () {
		Move(); //Call the enemy Move function

		//Check if damage should be shown
		if(framesRemaining >0)
		{
			framesRemaining--;
			if (framesRemaining == 0)
				DontShowDamage();
		}

	}

	//Move the enemy ship/asteroid in a stright line down the y-axis
	//Can be overridden by subclasses to make enemy move in different patterns
	public virtual void Move(){
		Vector3 tempPos = pos;
		tempPos.y -= speed * Time.deltaTime;
		pos = tempPos;
	}

	//Check the transform.position.y and destroy this gameobject if out of bounds.
	void CheckOffScreen()
	{
		
		if ( this.transform.position.y < boundary.yMin  || 
			 this.transform.position.y > boundary.yMax  ||
			 this.transform.position.x < boundary.xMin  || 
			 this.transform.position.x > boundary.xMax )
		{
			Debug.Log(this.transform.position + " Out of bounds");
			Destroy(this.gameObject);
		}
	}



	//On collision with object
	void OnCollisionEnter(Collision other)
	{
		GameObject go = other.gameObject;
		//print(other.gameObject.name);

		switch (go.tag)
		{
		//Player bullet collides with enemy
		case "PlayerProjectile":
			Projectile projectile = go.GetComponent<Projectile>();
			//Check if enemy is on screen if so ignore damage
			if(this.gameObject.transform.position.y >= screenTopEdge)
			{
				//print("Nana u cant hurt me =P");
				Destroy(go);
				break;
			}
			//Take damage
			health -= GameController.WEAPON_DEFS[projectile.type].damage; //Get damage value from WEAPON_DEFS 
			if (health <= 0){
				//Notify gamecontroller that this enemey was destroyed;
				if(!powerUpTriggered){
					powerUpTriggered =true;
					GameController.GAMECONTROLLER.EnemyDestroyed(this);
				}
				//Destroy this enemy
				Instantiate(explosion, this.transform.position, this.transform.rotation);
				Destroy(this.gameObject);
			}
			ShowDamage(); //Show that hit connected
			Destroy(go); //Destroy colliding object
			break;
		}
	}

	//Return a list of all materials on this gameobject
	private Material[] GetAllMaterials( GameObject go)
	{
		List<Material> materials = new List<Material>();
		if(go.GetComponent<Renderer>()!= null){
			materials.Add(go.GetComponent<Renderer>().material);
		}
			

		foreach(Transform t in go.transform)
		{
			materials.AddRange(GetAllMaterials(t.gameObject));	
		}
		return materials.ToArray();
	}

	//Changes the color of the materials in matterials to red to indicate damage
	public void ShowDamage(){
		foreach(Material m in materials)
			m.color = Color.white;
		framesRemaining = damageFrames;
	}

	//Return the original colors to the children of this enemey
	public void DontShowDamage()
	{
		for (int i = 0; i < materials.Length; i++)
		{
			materials[i].color = originalColors[i];	
		}
	}

	//Basic fire function that looks at player transform and fires at it
	public virtual void Fire()
	{
		GameObject player = GameObject.FindGameObjectWithTag("Player");
		foreach(Transform gun in guns){
			if(player){
				if(gun){
					gun.LookAt(player.transform.position);
					Instantiate(enemyProjectilePrefab, gun.position, gun.rotation);
				}
			}
			else return;
		}

		//Play sound when gun is fired
		if(gameObject.activeInHierarchy)
			GetComponent<AudioSource>().Play();
	}


	//Randomizes rate of fire
	public void SetFireRate()
	{
		Vector2 minMax = new Vector2( 0.5f, 5);
		float val = Random.Range(minMax.x,minMax.y);
		this.fireRate = val;
	}

	//Retuns the score value
	public int GetScore()
	{
		return score;
	}
}
