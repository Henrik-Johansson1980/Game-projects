﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProjectile : MonoBehaviour {

	public float speed = 20;
	public Boundary boundary;
	public Color[] colors;
	int colorIdx;

	// Use this for initialization
	void Awake()
	{
		colorIdx = 0;
		InvokeRepeating("CheckOffScreen", 0f, 1f);


	}
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		//ChangeColor();
		Move();
	}

	//Move projectile in the direction and distance of Translation
	void Move()
	{
		transform.Translate(0f,0f,Time.deltaTime*speed);
	}


	//Check the transform.position.y and destroy this gameobject if out of bounds.
	void CheckOffScreen()
	{

		if ( this.transform.position.y < boundary.yMin  || 
			this.transform.position.y > boundary.yMax  ||
			this.transform.position.x < boundary.xMin  || 
			this.transform.position.x > boundary.xMax )
		{
			//Debug.Log(this.transform.position + " Out of bounds");
			Destroy(this.gameObject);
		}
	}

	void ChangeColor()
	{
		colorIdx++;
		if ( colorIdx < colors.Length){
			this.gameObject.GetComponent<Renderer>().material.color = colors[colorIdx];	
		}
		else
			colorIdx = 0;
	}
}
