﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// Used by the end screen to reset score and lives 
// to their default values. 
public class ResetScoreAndLives : MonoBehaviour {

	// Use this for initialization
	void Start () {
		GameController.playerLives = 3;
		GameController.score = 0;
	}
}
