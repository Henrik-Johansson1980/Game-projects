﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//Script for enemyboss Boss A 
// Moves down a bit along the y-axis then starts 
//Moving in a sine wave pattern while shooting at 

public class EnemyG : Enemy {

	public float amplitude = 10f;
	public float birthTime;
	public float frequence;
	public float yRot = 10f;
	public float x = 0; //Center of screen in the x-axis

	public GameObject[] enemyPrefabs;

	void Start()
	{
		pos = new Vector3 ( 0,boundary.yMax,0);
		birthTime = Time.time;
		InvokeRepeating("Fire", 2f, fireRate);
	}


	//Overrides the base.move

	public override void Move()
	{
		//Move down a bit on the screen 
		if(this.transform.position.y >= boundary.yMax * 0.4 )
		{
			base.Move();
		}
		//then move along a sinewave pattern
		else
		{
			Vector3 tempPosition = pos;
			//theta adjusts based on time
			float age = Time.time - birthTime;
			float theta = Mathf.PI * 2 * age / frequence;
			float sin = Mathf.Sin(theta);
			tempPosition.x = x + amplitude * sin;
			pos = tempPosition;
			
			//Tilt ship a bit when turning
			Vector3 rot = new Vector3(0, sin*yRot,0);
			this.transform.rotation = Quaternion.Euler(rot);
		}
	}


	//Fires bullets in the direction of the player most of the time
	// Alternate fire: 
	// Spawns two smaller enemyships from the rear cannons
	public override void Fire ()
	{
		if(Random.value >= 0.1)
		{
			base.Fire ();
		}
			
		else
		{
			GameObject e = null;
			int idx = Random.Range(0,enemyPrefabs.Length);
			if(guns.Length == 4)
			{
				for(int i = 2; i < guns.Length; i++){
					e = Instantiate(enemyPrefabs[idx]);
					//e.transform.localScale = new Vector3 (0.5f, 0.5f, 0.5f);
					e.transform.position = guns[i].position;
				}
			}
			else return;
		}
	}

	//What happens on collisions with other objects
	void OnCollisionEnter(Collision other)
	{
		GameObject go = other.gameObject;
		print(other.gameObject.name);

		switch (go.tag)
		{
		case "PlayerProjectile":
			Projectile projectile = go.GetComponent<Projectile>();
			//Check if enemy is on screen if so ignore damage
			if(this.gameObject.transform.position.y >= screenTopEdge)
			{
				//print("Nana u cant hurt me =P");
				Destroy(go);
				break;
			}
			//Take damage
			health -= GameController.WEAPON_DEFS[projectile.type].damage; //Get damage value from WEAPON_DEFS 
			if (health <= 0){
				//Notify gamecontroller that this enemey was destroyed;
				if(!powerUpTriggered){
					powerUpTriggered =true;
					GameController.GAMECONTROLLER.EnemyDestroyed(this);
				}
				//Trigger explosion Destroy this enemy
				//Destroy this enemy and trigger explosions
				for (int i =0; i < 10; i++){
					GameObject exp = Instantiate(explosion);
					exp.transform.rotation = this.transform.rotation;
					Vector3 v = this.transform.position;
					v.x += Random.Range(-10f,10f);
					v.y += Random.Range(-10f,10f);
					exp.transform.position = v;
				}
				GameController.GAMECONTROLLER.EnableBossDefeated(); //When the boss is defeated notify the gamecontroller
				Destroy(this.gameObject);
			}
			ShowDamage();
			Destroy(go);
			break;
		}
	}
}
