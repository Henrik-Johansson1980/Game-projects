﻿using UnityEngine;
using System.Collections;

public class QuitGameOnKeyPress : MonoBehaviour {
	//Avslutar spelet vid knapptryckning, används av "credits skärmen"	
	// Update is called once per frame
	void Update () {
		if(Input.anyKeyDown){
			Application.Quit();
		}
	}
}
