﻿using UnityEngine;

using System.Collections;

public class Restart : MonoBehaviour {

	//Används av Try Again knappen
	public void RestartGame(){
		Application.LoadLevel(Application.loadedLevel); //Ladda om nuvarande scen.
	}
}
