﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Score : MonoBehaviour {
	private int catPointValue;
	private int blackCatPointValue = -500;
	private int goldCatPointValue = 1000;
	private int starPointValue = 200;
	private int starMultiplier = 2;
	private float starTime = 0;
	private float starTextTime = 0;
	private float blackTextTime = 0;

	public GameObject starPowerUpText;
	public GameObject blackText;
	public Text scoreText;

	static int score;
	static int highScore;

	void Start(){
		//Läs in sparad Highscore
		highScore = PlayerPrefs.GetInt("HighScore", 0);
		score = 0;
		UpdateScoreText();//Skriv ut nuvarande poäng (0) på skärmen 
	}

	void Update(){
	
		//Om starpower är aktiv (se OnTriggerEnter2Dfunktionen nedan) starta nedräkning 
		if(starTime > 0)
		{
			starTime -= Time.deltaTime;
		}
		//om star power är inaktiv dela ut normala poäng
		else {
			catPointValue = 100;
			goldCatPointValue = 1000;
		}
		//Visa Powerup meddelande vid infångad stjärna
		if(starTextTime > 0)
		{
			starTextTime -= Time.deltaTime;
			starPowerUpText.SetActive(true);
		}
		else
			starPowerUpText.SetActive(false);

		//Visa svart katt meddelande vid fångad svart katt
		if(blackTextTime > 0)
		{
			blackTextTime -= Time.deltaTime;
			blackText.SetActive(true);
		}
		else
			blackText.SetActive(false);
	}

	void OnTriggerEnter2D (Collider2D other){

		//Om spelet är igång och någon av de fångade katterna inte är svart, gyllene eller en stjärna
		// Uppdatera poängen.
		if (other.tag == "BrownCat" 
		    || other.tag == "BrownStripedCat"  
		    || other.tag == "GrayStripedCat"  
		    || other.tag == "WhiteCat"
		    && EndGameOnContact.catOnGround == false) {
	
			score += catPointValue;
			CheckScore();
			UpdateScoreText();
		} 
		//Om spelet är igång och någon av de fångade katterna är svart
		// Uppdatera poängen.
		if (other.tag == "BlackCat" && EndGameOnContact.catOnGround == false){
			score += blackCatPointValue;
			CheckScore();
			UpdateScoreText ();
			blackTextTime = 1.0f;
		}
		//Om spelet är igång och någon av de fångade katterna är gyllene
		// Uppdatera poängen.
		if (other.tag == "GoldenCat" && EndGameOnContact.catOnGround == false) {
			score += goldCatPointValue;
			CheckScore();
			UpdateScoreText ();

		}
		//Om spelet är igång och om det infångade objektet är en stjärna
		// Uppdatera poängen.
		if (other.tag == "Star" && EndGameOnContact.catOnGround == false) {
			score += starPointValue;
			CheckScore();
			UpdateScoreText ();
			starTime = 3.0f;
			starTextTime = 1.0f;
			catPointValue *= starMultiplier;
			goldCatPointValue *= starMultiplier;
		}
	}

	//Funktions om uppdaterar poängen
	void UpdateScoreText(){
		if(EndGameOnContact.catOnGround == false) //Om ingen katt träffat marken
			scoreText.text = "High Score: " + highScore + "\nScore: " + score ;
	}

	//Funktion som kontrollerar om nuvarande poäng är högre än high score, och i så fall 
	// även tilldelar nuvarande poäng till high score.
	void CheckScore(){
		if (score > highScore)
			highScore = score;
	}

	//Spara high score mellan spel
	void OnDestroy(){
		PlayerPrefs.SetInt("HighScore", highScore); 	
	}
}
	