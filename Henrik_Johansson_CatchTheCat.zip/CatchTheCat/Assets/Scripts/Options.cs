﻿using UnityEngine;
using System.Collections;

public class Options : MonoBehaviour {
	//Används av knapp för att komma till optionmenyn
	public void ToOptions(){
		Application.LoadLevel("Options");
	}
}
