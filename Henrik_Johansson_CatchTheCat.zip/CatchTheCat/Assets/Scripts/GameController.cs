﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour {
	public Camera cam;
	public GameObject groundSurface;
	public GameObject gameOverText;
	public GameObject restartButton;
	public GameObject pauseQuitToMenuButton;
	public GameObject pauseQuitGameButton;
	public GameObject toMenuButton;
	public GameObject quitButton;
	public GameObject pauseText;
	public GameObject easyGame;
	public GameObject mediumGame;
	public GameObject hardGame;
	public GameObject[] randomObjects; 	//Samling med olika objekt som släpps ned
	public AudioClip[] meowSound;		//Samlig av olika ljudklipp när katterna spawnas
	public AudioClip[]ohNoSound;		//Samlig av olika ljudklipp när katter slår i marken
	public AudioClip[] bGMusic;			//Samlig med olika bakgrundsmusik
	public float vol;
	public AudioSource source;
	public static bool gameOn; 	//Används av Basketcontroller scriptet för att slå på/av möjligheten att
								//kontrollera korgen.
	private float timer;
	private GameObject fallingObject; 
	private float maxWidth; 		//Spelområdets maxbredd
	
	// Use this for initialization
	void Start () {

		gameOn = true; //Låt spelaren kontrollera korgen
		EndGameOnContact.catOnGround = false;
		timer = 0; //Sätt spelets klocka till 0

		//Kontrollera svårighetsgrad och aktivera motvarande korg. Medium är standard.
		if(Easy.easyMode == true)
			easyGame.SetActive(true);
		else if (Medium.mediumMode == true)
			mediumGame.SetActive(true);
		else if (Hard.hardMode == true)
			hardGame.SetActive(true);
		else
			mediumGame.SetActive(true);

		//Ljud
		source = GetComponent<AudioSource>();
		source.clip = bGMusic[Random.Range(0, bGMusic.Length)]; //Slumpa bakgrundsmusik
		source.volume = vol; //Tilldela volym (0.0-1.0)
		source.Play(); //Starta klipp

		//hitta övre vänstra hörnet på skärmen
		Vector3 upperCorner = new Vector3(Screen.width, Screen.height, 0.0f);
		Vector3 targetWidth = cam.ScreenToWorldPoint (upperCorner);
		//Hämta storleken från den första katten i arrayen för att släppa ned objekten inom spelområdet
		float catWidth = randomObjects[0].GetComponent<Renderer>().bounds.extents.x;
		maxWidth = targetWidth.x - catWidth;

		StartCoroutine (Spawn()); // Börja släppa ned objekt
	}

	void Update(){

		//Om spelet körs uppdatera timern
		if (EndGameOnContact.catOnGround == false){
			timer += Time.deltaTime;
			//Debug.Log(timer);
		}

		//Pausa med esc
		if(Input.GetKeyDown(KeyCode.Escape))
			PauseGame();

		//Om spelet inte är pausat inaktivera paustexten
		if(Time.timeScale == 1){
			pauseText.SetActive(false);
			pauseQuitGameButton.SetActive(false);
			pauseQuitToMenuButton.SetActive(false);
		}
	}

	//Spawnfunktionen skapar obejkt och släpper ned dem på olika positioner i x-led
	IEnumerator Spawn(){
		yield return new WaitForSeconds (2.0f); //Vänta två sekunder innan katterna börjar spawnas.

		//Så länge ingen katt nuddat marken.
		while(EndGameOnContact.catOnGround == false){
	
			fallingObject = randomObjects[Random.Range(0, randomObjects.Length)];
			Vector3 spawnPosition = new Vector3(Random.Range(-maxWidth, maxWidth),transform.position.y, 0.0f);
			Instantiate (fallingObject, spawnPosition, fallingObject.transform.rotation);
			//Spela kattljud om objectet inte är en stjärna
			if(!(fallingObject.tag == "Star"))
				source.PlayOneShot(meowSound[Random.Range(0, meowSound.Length)], 0.3f);

			//Justera svårighetsgraden med tiden genom att minska intervallet mellan nedsläppen
			if(timer < 30)
				yield return new WaitForSeconds(Random.Range (1.0f, 2.0f)); //Vänta 1 till 2 sek mellan nedsläppningar
			if(timer > 30 && timer < 60)
				yield return new WaitForSeconds(Random.Range (1.0f, 1.5f)); //Vänta 1 till 1,5 sek mellan nedsläppningar
			if(timer > 60 && timer < 90)
				yield return new WaitForSeconds(Random.Range (0.5f, 1.2f)); //Vänta 0,5 till 1,2 sek mellan nedsläppningar
			if(timer > 90 && timer < 120)
				yield return new WaitForSeconds(Random.Range (0.5f, 1.0f)); //Vänta 0,5 till 1 sek mellan nedsläppningar
			if(timer > 120 && timer < 160)
				yield return new WaitForSeconds(Random.Range (0.4f, 0.7f)); //Vänta 0,4 till 0,6 sek mellan nedsläppningar
			if(timer > 160)
				yield return new WaitForSeconds(Random.Range (0.3f, 0.5f)); //Vänta 0,3 till 0,5 sek mellan nedsläppningar

			//Starta ytterligare en coroutine om timern är jämt delbar med 160 eller 320 sekunder
			if (timer % 160 == 0 || timer % 320 == 0) 
				StartCoroutine(Spawn ());

		}

		if(EndGameOnContact.catOnGround == true)
		{
			//Spelet är slut
			gameOn = false;
			gameOverText.SetActive(true); 
			source.Stop(); //Stoppa bakgrundsmusik
			//vänta en stund
			yield return new WaitForSeconds (1.0f);
			source.PlayOneShot(ohNoSound[Random.Range(0, ohNoSound.Length)], 0.8f); //Spela ett av klippen
			//Aktivera knappar
			restartButton.SetActive(true);
			toMenuButton.SetActive(true);
			quitButton.SetActive(true);
		}

	}

	//Funktion som anropas när spelaren trycker på esc tangenten
	public void PauseGame(){

		Time.timeScale = Time.timeScale == 0 ? 1:0; //Slå av/på paus när esc-tangenten trycks ned.
		pauseText.SetActive(true); //Aktivera pausetext.
		pauseQuitGameButton.SetActive(true);
		pauseQuitToMenuButton.SetActive(true);

	}
}

