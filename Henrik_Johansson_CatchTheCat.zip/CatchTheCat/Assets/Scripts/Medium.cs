﻿using UnityEngine;
using System.Collections;

public class Medium : MonoBehaviour {

	public static bool mediumMode; //Kan anropas av av andra script, bl.a gamecontrollern
	// Use this for initialization
	void Start () {
		mediumMode = false;
	}

	//Används på knapp vid val av svårighetsgrad
	public void MediumSetting(){
		//Aktivera medium och inaktivera de övriga
		mediumMode = true;
		Easy.easyMode = false;
		Hard.hardMode= false;
		Application.LoadLevel("StartScreen"); //Återgå till startskärmen
	}
}

