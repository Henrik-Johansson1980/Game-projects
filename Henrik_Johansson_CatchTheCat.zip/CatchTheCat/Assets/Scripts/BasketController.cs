﻿using UnityEngine;
using System.Collections;

public class BasketController : MonoBehaviour {
	public Camera cam;
	private bool canControl;
	private float maxWidth;	//Spelområdets maxbredd
	public GameObject catcher;
	public GameObject dontWalk;
	Rigidbody2D rb;

	// Use this for initialization
	void Start () {
		//hitta övre vänstra hörnet på skärmen
		Vector3 upperCorner = new Vector3(Screen.width, Screen.height, 0.0f);
		Vector3 targetWidth = cam.ScreenToWorldPoint (upperCorner);
		float hatWidth = GetComponent<Renderer>().bounds.extents.x;
		maxWidth = targetWidth.x - hatWidth;

		//tilldela en Rigidbody2D
		rb = GetComponent<Rigidbody2D>();

	}
	
	// Update is called once per frame
	void FixedUpdate () {

		//Om spelet inte är igång stäng av möjligheten att flytta korgen
			if(GameController.gameOn == false)
		{
			canControl = false; //Frys kontrollen av korgen
			catcher.SetActive(false); //Inaktivera animerad sprite
			dontWalk.SetActive(true); //Aktivera stillastående sprite
		}
		else
		{
			canControl = true; //Tillåt att korgen går att kontrollera
			catcher.SetActive(true); //Kör animerad (gående) sprite 
			dontWalk.SetActive(false); //Inaktivera stillastående sprite
		}
		//Om korgen kan kontrolleras
		if (canControl) {
			//Kontrollera korgen med musen (x-led)
			Vector3 rawPosition = cam.ScreenToWorldPoint (Input.mousePosition);
			Vector3 targetPosition = new Vector3 (rawPosition.x, 0.0f, 0.0f);
			//Håll korgen inom spelområdet
			float targetWidth = Mathf.Clamp (targetPosition.x, -maxWidth, maxWidth);
			//Räkna ut var pekaren är och flytta korgen dit
			targetPosition = new Vector3 (targetWidth, targetPosition.y, targetPosition.z);
			rb.MovePosition (targetPosition);
		}
	}
}
