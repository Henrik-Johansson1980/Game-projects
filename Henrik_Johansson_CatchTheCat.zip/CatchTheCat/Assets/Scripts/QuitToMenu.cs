﻿using UnityEngine;
using System.Collections;

public class QuitToMenu : MonoBehaviour {

	//Återgår till startmenyn, används av knappen Quit to menu.
	public void ExitToMenu(){
		Application.LoadLevel("StartScreen");
		if (Time.timeScale == 0)
			Time.timeScale = 1;
	}
}


