﻿using UnityEngine;
using System.Collections;

	public class EndGameOnContact : MonoBehaviour {
		static public bool catOnGround; //Kan anropas av andra skript bl.a gamekontrollern.
		public AudioClip groundMeow;	
		public AudioSource source;
	
	void Start(){

			source = GetComponent<AudioSource>();
		}

		//Om någon av katterna, förutom den svarta träffar marken är spelet slut.
	void OnTriggerEnter2D (Collider2D other)
	{
		if (other.tag == "BrownCat" || other.tag == "BrownStripedCat" || 
	    	other.tag == "GrayStripedCat" || other.tag == "WhiteCat" || 
	    	other.tag == "GoldenCat"){

				catOnGround = true;
				source.clip = groundMeow;
				//Spela inte upp klippet om ytterligare en katt träffar marken samtidigt som
				//klippet spelas upp.
				if(!source.isPlaying) 	//Om klippet inte körs
					source.Play();		//Spela klipp.

		}
	}
}
