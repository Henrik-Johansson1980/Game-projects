﻿using UnityEngine;
using System.Collections;

public class StartGamePressed : MonoBehaviour {

	//Startar spelet, används av knappen start game på huvudmenyn
	public void StartGame(){
		Application.LoadLevel("Game"); // Ladda Game scenen
	}
}
