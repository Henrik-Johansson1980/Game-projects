﻿using UnityEngine;
using System.Collections;

public class QuitGameButton : MonoBehaviour {

	//Används av exit game knappen 
	public void ExitGame(){
		Application.LoadLevel("Credits"); //Visa credits skärmen
	} 
}
