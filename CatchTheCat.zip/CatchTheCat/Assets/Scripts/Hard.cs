﻿using UnityEngine;
using System.Collections;

public class Hard : MonoBehaviour {

	
	public static bool hardMode; //Kan anropas av av andra script, bl.a gamecontrollern
	// Use this for initialization
	void Start () {
		hardMode = false;
	}
	//Används på knapp vid val av svårighetsgrad
	public void HardSetting(){
		//Aktivera hardmode och inaktivera de övriga.
		hardMode = true;
		Easy.easyMode = false;
		Medium.mediumMode = false;
		Application.LoadLevel("StartScreen"); //Återgå till startskärmen
	}
}
