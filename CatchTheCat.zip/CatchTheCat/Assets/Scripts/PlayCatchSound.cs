﻿using UnityEngine;
using System.Collections;

public class PlayCatchSound : MonoBehaviour {
	public AudioSource source;

	//Samlingar med ljudklipp att spela upp när objekt fångas upp
	public AudioClip[] catchClips;
	public AudioClip[] blackCatch;
	public AudioClip[] starClips;
	public AudioClip[] goldenCatclips;

	// Use this for initialization
	void Start () {
		source = GetComponent<AudioSource>();
	}

	//Spela upp något av ljudklippen i samlingarna när objekt av en viss sort fångas.
	void OnTriggerEnter2D(Collider2D other){

		if(other.tag == "BlackCat")
			source.PlayOneShot(blackCatch[Random.Range(0, blackCatch.Length)], 0.2f );
		else if (other.tag == "Star")
			source.PlayOneShot(starClips[Random.Range(0, starClips.Length)], 0.2f );
		else if (other.tag == "GoldenCat")
			source.PlayOneShot(goldenCatclips[Random.Range(0, goldenCatclips.Length)], 0.2f );
		else
			source.PlayOneShot(catchClips[Random.Range(0, catchClips.Length)], 0.5f);
	}
}
