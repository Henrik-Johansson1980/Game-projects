===================================================
                8Bit Classic Free
===================================================

8bit arrange of famous classical music !
This asset is free version.

- 5 tracks
- 256 kbps, mp3

All tracks are arranged by OTOnoniwa

- Pavane for a Dead Princess / Satie
- Courante / Lully
- Je te veux / Satie
- Ave Maria / Bach/Gounod
- Pachelbel's Canon / Pachelbel


If you want more tracks, check following assets.

8Bit Classic Vol. 1
　https://www.assetstore.unity3d.com/jp/#!/content/20624

8Bit Classic Vol. 2
　https://www.assetstore.unity3d.com/jp/#!/content/20671


===================================================
                About Audiostock
===================================================
Audiostock is a crowdsourcing service specialized in
selling tunes, sound effects, and voices made by
creators all over Japan.
At Unity Asset Store, we sell good sound sources 
for game creation selected from the ones registered
at Audiostock.


Audiostock
http://www.audiostock.jp

contact us
staff@audiostock.jp


Thanks for downloading !