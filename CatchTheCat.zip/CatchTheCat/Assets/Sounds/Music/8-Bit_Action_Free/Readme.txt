�y8-Bit_Action_Free�z

Free package 8-BIT loop music of these five included is perfect for retro action game.
All Tracks are seamless looping wave files at 44,100 Hz, 16 Bit, Stereo. 
Full Pack coming soon.


-For Unity User
This asset is governed by the Terms and Conditions of Unity.
http://unity3d.com/legal/as_terms

-For not Unity User
available to users who have bought
you will not reproduce, duplicate, copy, sell, 
trade or resell this Asset that you have acquired.



�y8-Bit Action is available!�z
Over 40 Tracks, seamless looping wave files at 44,100 Hz, 16 Bit, Stereo. 

Sounds Demo is here
https://soundcloud.com/moppysound/8-bit-action-crossfade

��For Unity Users!
The full package 8-BIT loop music is perfect for retro action game.
Over 40 Tracks, wave files at 44,100 Hz, 16 Bit, Stereo.
www.assetstore.unity3d.com/jp/#!/content/20224

��For Not Unity Users!
Please purchase from the following URL
https://moppysound.stores.jp/#!/items/54097c5bef3377f0f80000ec




�yAbout me�z

MoppySound (Composer / Arranger)
MoppySound began to offer music material in Unity in 2014.
I provide the music rustic to match the game.
I hope my music becomes the help of a nice game production.

WebSite�Fhttp://moppysound.seesaa.net/


A nice music in a nice game. 

Thanks for download and reading.


Copyright (C) 2014 MoppySound All Rights Reserved.

