﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

[ExecuteInEditMode]
public class PlayerController : MonoBehaviour
{
	public int speed = 100;
	public Text scoreText;
	public Text winText;
	public Text clearTimeText;
	public Text timeCounterText;
	public Text playAgaintText;
	public AudioClip collectSound;
	public AudioClip stageCleared;

	private AudioSource source;
	private int scoreCount;
	private Rigidbody rb;

	private bool restart;

	void Start ()
	{
		restart = false;
		scoreCount = 0;
		winText.text = "";
		timeCounterText.text = "Ready";
		clearTimeText.text = "";
		SetCounterText();
		playAgaintText.text = "";
		rb = GetComponent<Rigidbody> ();
	}
	void Update ()
	{
		if(restart){

			if(Input.GetKeyDown(KeyCode.Y)) {
			Application.LoadLevel(Application.loadedLevel);
			}

			if (Input.GetKeyDown(KeyCode.N)){
			Application.LoadLevel("Credits");
			}
		}

	}

	void FixedUpdate()
	{
		float moveHorizontal = Input.GetAxis ("Horizontal");	
		float moveVertical = Input.GetAxis ("Vertical");
		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);
		rb.AddForce (movement * speed);
		if (timeCounterText != null){
		//Skriver ut tiden som gått sedan leveln laddats
		timeCounterText.text = "TIME: " + (Time.timeSinceLevelLoad).ToString("00"); 
		}
	}

	void OnTriggerEnter (Collider other)
	{
		if (other.gameObject.tag == "PickUp") {
			AudioSource.PlayClipAtPoint(collectSound,transform.position, 0.06F);
			other.gameObject.SetActive (false);
			scoreCount++;
			SetCounterText();

		}
	}

	void SetCounterText()
	{
		if (scoreText != null)
			scoreText.text = "SCORE: " + scoreCount.ToString();

		if (scoreCount >= 12)
		{
			Destroy(timeCounterText);	
			Destroy(scoreText);
			GameObject.Find( "BackgroundMusic").SetActive(false); //Stäng av musik
			AudioSource.PlayClipAtPoint(stageCleared ,gameObject.transform.position, 0.04F); // Spela stage-clear truddelutt
			rb.isKinematic = true; //lås kulan
			winText.text = "STAGE CLEAR!"; 
			clearTimeText.text = "CLEAR TIME: " + Time.timeSinceLevelLoad.ToString("00") + " seconds"; //Skriver ut tiden det tog att samla pickups
			playAgaintText.text = "Would you like to try again?\n Press (Y/N)"; //Spela igen
			restart = true;
		}
	}
}