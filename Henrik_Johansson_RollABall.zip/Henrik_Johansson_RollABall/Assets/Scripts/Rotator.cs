﻿using UnityEngine;
using System.Collections;

public class Rotator : MonoBehaviour {
	public int rotateSpeed = 3;
		
	void Update () 
	{
		transform.Rotate(new Vector3(15, 0, 45) * Time.deltaTime * rotateSpeed); 
	}
}
