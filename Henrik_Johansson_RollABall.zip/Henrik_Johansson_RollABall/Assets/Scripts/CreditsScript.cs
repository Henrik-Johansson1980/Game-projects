﻿using UnityEngine;
using System.Collections;

public class CreditsScript : MonoBehaviour {

	void Update () {
	
		if(Input.anyKeyDown){
			Application.Quit();
		}
	}
}
