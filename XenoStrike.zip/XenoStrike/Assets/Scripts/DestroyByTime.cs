﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//Destroys this object after 2 seconds
public class DestroyByTime : MonoBehaviour {

	float birthtime;
	float lifetime = 2f;
	// Use this for initialization
	void Start () {
		birthtime = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		if (Time.time - birthtime >= lifetime)
		{
			Destroy(this.gameObject);
		}
	}
}
