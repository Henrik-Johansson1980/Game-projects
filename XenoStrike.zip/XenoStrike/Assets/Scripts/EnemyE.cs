﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//Class that represents a part on the ship
// this can be protected by other parts that has to be
// destroyed before the part can be destroyed
[System.Serializable]
public class Part 
{
	public string name; //Name of the part
	public float health; //Amount of health 
	public string[] protectedBy; //Parts that protects this part
	public GameObject go;
	public Material mat;
}

//Enemy that repeatedly chooses random points on screen and moves to that point
// Used as a boss pattern for Boss B and Boss c
public class EnemyE : Enemy {

	public Vector3[] points;
	public float moveStartTime;  //Time of birth 
	public float moveDuration =  4;	//Duration of movement
	public float padding = 5;

	public Part[] parts; //Set in inspector
	public GameObject[] enemies; //Enemis that can be spawned by boss
 
	// Use this for initialization
	void Start () {

		points = new Vector3[2]; // Array with Two points 

		//Get startpos from gamecontroller
		points[0] = pos;
		points[1] = pos;

		InitMovement(); 

		//Get the materials
		Transform t;
		foreach(Part p in parts)
		{
			t = transform.Find(p.name);
			if(t !=  null)
			{
				p.go = t.gameObject;
				p.mat = p.go.GetComponent<Renderer>().material;
			}
		}

		//Invoke the fire function
		InvokeRepeating("Fire", fireRate, fireRate);
	}

	public void InitMovement()
	{
		//Pick a point to move to
		Vector3 destination = Vector3.zero;
		destination.x = Random.Range(boundary.xMin + padding, boundary.xMax - padding);
		destination.y = Random.Range(boundary.yMin + padding, boundary.yMax - padding);

		//Set the old destination point to the new startpoint
		points[0] = points[1];
		//assign the new point as the destination point
		points[1] = destination;
	
		//Reset time
		moveStartTime = Time.time;

	}

	//Override Enemy.Move() with a linear interpolation movent scheme
	public override void Move()
	{
		float u = (Time.time - moveStartTime)/moveDuration;

		if(u>=1)
		{
			InitMovement(); //Move intialize movement to a new point
			u=0;
		}

		u = 1 - Mathf.Pow(1-u,2);  //Apply easing out to u
		pos = (1-u)*points[0] + u*points[1]; //Linear interpolation

		//base.Move();
	}

	void OnCollisionEnter(Collision coll)
	{
		GameObject other = coll.gameObject;
		switch(other.tag)
		{
			case "PlayerProjectile": 
			Projectile p = other.GetComponent<Projectile>();
			//If enemy is above screenedge
			if (this.transform.position.y > screenTopEdge){
				Destroy(other);
				return;
			}

			//Hurt enemy
			GameObject hitObj = coll.contacts[0].thisCollider.gameObject;
			Part hitPart = FindPart(hitObj);
			if(hitPart == null)
			{
				hitObj = coll.contacts[0].otherCollider.gameObject;
				hitPart = FindPart(hitObj);
			}
			//if the hit part is protected
			if(hitPart.protectedBy != null)
			{
				foreach(string s in hitPart.protectedBy)
				{
					//If the protecting part still exists 
					//don't damage this part
					if(!Destroyed(s)){
						Destroy(other); //Destroy projectile
						return;
					}
				}
			}

			//If part isn't protected, take damage from projectile
			hitPart.health -= GameController.WEAPON_DEFS[p.type].damage;
			//Showdamage on part
			ShowPartDamage(hitPart.mat);
			if(hitPart.health <= 0)
			{
				Instantiate(explosion, hitPart.go.transform.position, hitPart.go.transform.rotation);
				Destroy( hitPart.go);
				//hitPart.go.SetActive(false);	
			}

			//check if all parts are destroyed
			bool allDestroyed = true; //assume all parts are destroyed
			//loop through parts array
			foreach(Part prt in parts)
			{
				if(!Destroyed(prt)) //If a part is active
					{
						allDestroyed = false; 
						break; //leave loop
					}
			}
			//if all parts are destroyed
			if(allDestroyed)
			{

				//Spawn power up 
				if(!powerUpTriggered){
					powerUpTriggered =true;
					GameController.GAMECONTROLLER.EnemyDestroyed(this);
				}
				//Destroy this enemy and trigger a few explosions 
				for (int i =0; i < 10; i++){
					GameObject exp = Instantiate(explosion);
					exp.transform.rotation = this.transform.rotation;
					Vector3 v = this.transform.position;
					v.x += Random.Range(-10f,10f);
					v.y += Random.Range(-10f,10f);
					exp.transform.position = v;
				}
				GameController.GAMECONTROLLER.EnableBossDefeated(); //When the boss is defeated notify the gamecontroller so it loads next level
				Destroy(this.gameObject);
			}

			Destroy(other); //Destroy player bullet
			break;
		}
	}


	//Locate a part in parts[] by name
	Part FindPart(string n)
	{
		foreach(Part p in parts)
		{
			if(p.name == n)
				return p;
		}
		return null;
	}


	//Locate a part in parts[] by gameobj
	Part FindPart(GameObject go)
	{
		foreach(Part p in parts)
		{
			if(p.go == go)
				return p;
		}
		return null;
	}

	//Check if part has been destroyed
	//returns true/false
	bool Destroyed(GameObject go)
	{
		return(Destroyed(FindPart(go)));
	}

	bool Destroyed(string n)
	{
		return(Destroyed(FindPart(n)));
	}

	bool Destroyed(Part prt)
	{
		if(prt == null)
		{
			return true;	
		}
		return (prt.health <= 0);
	}

	//Change coleor on hit
	void ShowPartDamage(Material m)
	{
		if(this.name.Contains("Boss B"))
			m.color = Color.red;
		else
			m.color = Color.white;
		framesRemaining = damageFrames;
	}


	//Overrides base.Fire()
	public override void Fire ()
	{
		//Loop through the guns on ship
		foreach(Transform g in guns)
		{ 
			if (g != null)

			if(g){
				GameObject player = GameObject.FindGameObjectWithTag("Player");
			
				//The "main gun" sits on the fueslage of the ship
 				if (g.name == "Main Gun"){
					if(player){
						g.LookAt(player.transform);
						FireMainGun(g);
					}
				}
				//Standard enemy gun that fires bullets at the players current location
				if (g.name == "Gun"){
					if(player)
						g.LookAt(player.transform);
					Instantiate(enemyProjectilePrefab, g.position,g.rotation);
				}

				//Guns on wings fire straight up or down (on y-axis)
				// depending on the ships position
				if (g.name == "S Gun"){
					
					Quaternion q = Quaternion.identity;
					g.rotation=q;
					if(this.transform.position.y > 0) 
						g.Rotate(90,0,0);
					else
						g.Rotate(-90,0,0);
					Instantiate(enemyProjectilePrefab, g.position, g.rotation);
				}
				//Play sound when gun is fired
				if(GetComponent<AudioSource>())
					GetComponent<AudioSource>().Play();
			}
		}
	}
		

	//Fires a ring of bullets 
	void FireMainGun(Transform gun)
	{
		//Counter for active guns
		int c = 0;
		foreach(Transform g in guns){
			if(g != null)
				c++;
		}

		//Fires a ring of bullets
		for (int i = 0 ; i < 360 ; i += 15){
			gun.Rotate(i,0,0);
			Instantiate(enemyProjectilePrefab, gun.position,gun.rotation);
		}

		//if only one gun remains (main gun) it's possible that an enemy spawns from the boss
		if (c == 1){
			if (this.transform.position.y >boundary.yMax/2){
				if(Random.value <0.2f){
					GameObject e =Instantiate(enemies[Random.Range(0,enemies.Length)]);
					e.transform.position = this.transform.position;
				}
			}
		}
	}
}
