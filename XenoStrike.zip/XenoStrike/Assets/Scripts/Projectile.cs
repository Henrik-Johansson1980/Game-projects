﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour {
	[SerializeField]
	private WeaponType _type;
	public Boundary boundary; //Boundary of screen used to check if this projectile is out of bounds

	public WeaponType type {
		get
		{
			return (_type);
		}
		set
		{
			SetType(value);
		}
	}

	//Function to set weapontype
	public void SetType(WeaponType eType)
	{
		_type = eType;
		WeaponDefinition wDef = GameController.GetWeaponDefinition(_type);
		GetComponent<Renderer>().material.color = wDef.projectileColor;
	}

	void Awake()
	{
		InvokeRepeating("CheckBoundary",0f,1f);

	}
		
	//Destroy projectile if out of bounds
	void CheckBoundary()
	{
		if(this.transform.position.y > boundary.yMax || 
			this.transform.position.y < boundary.yMin ||
			this.transform.position.x < boundary.xMin ||
			this.transform.position.x > boundary.xMax
		)
			Destroy(this.gameObject);
	}
}
