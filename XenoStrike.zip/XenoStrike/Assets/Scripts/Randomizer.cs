﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//USed to randomize the behaviour of asteroids
public class Randomizer : MonoBehaviour {

	float scale;
	float tumbleX, tumbleY,tumbleZ;
	float randRotate;

	// Use this for initialization
	void Start () {
		//Randomzie values for rotation and rot speed
		tumbleX = Random.Range(1,360);
		tumbleY = Random.Range(1,360);
		tumbleZ = Random.Range(1,360);
		randRotate = Random.Range(1,3);
		scale = Random.Range(3,15);

		gameObject.GetComponent<Enemy>().speed = Random.Range(5,25);

		transform.rotation = Quaternion.Euler(tumbleX,tumbleY,tumbleZ);
	
		transform.localScale += new Vector3 (scale,scale,scale);
	}

	// Update is called once per frame
	void Update () {
		//Rotate the transform
		transform.Rotate(randRotate,randRotate,randRotate);
	}
}
