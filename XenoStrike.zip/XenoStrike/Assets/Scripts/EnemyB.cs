﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//EnemyB extends Enemy
//EnemyB moves in a Sinewave pattern
public class EnemyB : Enemy {

	public float waveFrequency = 2; //seconds for a full sine wave
	public float waveWidth = 10;
	public float waveRotationY = 45;

	private float x0 = 0	; //Initital value of xPos;
	private float birthTime;

	// Use this for initialization
	void Start () {
		//Set x0 to the initial position of EnemyB
		//pos.x has been set by Gamcontrollers spawnfunctions
		x0 = pos.x;

		birthTime = Time.time; //Set bithtime

		Invoke("Fire", fireRate);
	}

	//Override EnemyClass Move function
	public override void Move ()
	{

		//Make an editable vector3 to be able to set the x.pos
		Vector3 tempPosition = pos;
		//theta adjusts based on time
		float age = Time.time - birthTime;
		float theta = Mathf.PI * 2 * age / waveFrequency;
		float sin = Mathf.Sin(theta);
		tempPosition.x = x0 + waveWidth * sin;
		pos = tempPosition;

		//Tilt ship a bit when turning
		Vector3 rot = new Vector3(0, sin*waveRotationY,0);
		this.transform.rotation = Quaternion.Euler(rot);
		//base moves enemy along the y-axis
		base.Move ();
	}

	public override void Fire ()
	{
//		foreach(Transform gun in guns)
//		{
//			Instantiate(enemyProjectilePrefab,gun.position, gun.rotation);
//		}
		base.Fire();
		Invoke("Fire", fireRate);
	}
}
