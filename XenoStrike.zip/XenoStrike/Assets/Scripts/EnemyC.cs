﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//EnemyC move via a 2-point linear interpolation
//A sinve wave is used to modify the linear interpolation
// The enemey rotates so it's bullets fly in a swirl pattern
// this script is used by enemyc and e
public class EnemyC : Enemy {

	public Vector3[] points;
	public float birthTime;
	public float lifeTime =10f;
	public float padding = 10f;
	public float sinEccentricity = 0.6f;
	public float rotSpeed = 50f;
	// Use this for initialization
	void Start () {
		//Initialize points
		points = new Vector3[2];
		//Pick a point between yMin/yMax at left of screen
		Vector3 vec = Vector3.zero;
		vec.x = boundary.xMin;
		vec.y = Random.Range(boundary.yMin, boundary.yMax);
		points[0] = vec;

		//Pick a point between yMin/yMax at right of screen
		vec = Vector3.zero;
		vec.x = boundary.xMax;
		vec.y = Random.Range(boundary.yMin, boundary.yMax);
		points[1] = vec;

		//Randomize side
		if(Random.value<0.5f)
		{
  			//Reverse points
			points[0].x *= -1;
			points[1].x *= -1;

		}

		birthTime = Time.time;

		InvokeRepeating("Fire", fireRate, fireRate);
	}
		

	public override void Move ()
	{
		//Bezier curves work based on the value of u ranging between 0 and 1
		float u = (Time.time-birthTime)/lifeTime;

		//if u gets larger than 1 more time than lifetime has passed since birth
		if(u>1)
		{
			//This enemy has lived long enough 
			Destroy(this.gameObject);
			return;
		}

		//Change u by adding an easing curve based on a Sine wave
		u = u + sinEccentricity * (Mathf.Sin (u * Mathf.PI* 2));

		//interpolate the two linear interpolation points
		pos = (1-u)*points[0] + u*points[1];

		//Rotate enemy transform
		this.transform.Rotate(Vector3.forward, rotSpeed* Time.deltaTime);
	}

	//override base.fire 
	//since the enemy rotates the guns fire at diffrent positions/rotations
	public override void Fire ()
	{
		foreach(Transform gun in guns)
		{
			Instantiate(enemyProjectilePrefab, gun.position,gun.rotation);
		}
	}
}
