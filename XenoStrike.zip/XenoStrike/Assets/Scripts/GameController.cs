﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

	static public GameController GAMECONTROLLER;
	static public Dictionary<WeaponType, WeaponDefinition> WEAPON_DEFS;
	static public int playerLives = 3;
	static public int score;
	public GUIText[] texts;
	public List<GameObject> enemyPrefabs;
	public WeaponDefinition[] weaponDefinitions;
	public WeaponType[] activeWeaponTypes;
	public float spawnRate = 2f; //Time in seconds between enemySpawn 
	public float waveTime = 12f;
	public float offset = 2 ;
	public float yMaxOffset = 5;
	public Boundary boundary;
	public GameObject powerupPrefab;
	GameObject player;
	private int index = 0;
	private Vector3 spawnPos;
	bool enableLeveltext;
	bool bossDefeated = false;

	float startTime, timer;

	//Array of weapontypes to be dropped as powerups duplicates = increased dropchance
	public WeaponType[] powerUpFrequency = new WeaponType[]
	{
		WeaponType.blaster,
		WeaponType.blaster, 
		WeaponType.blaster, 
		WeaponType.spread,
		WeaponType.rapid
	};

	void Awake()
	{
		if (GAMECONTROLLER == null)
			GAMECONTROLLER = this;

		//Generic Dictionary that uses the Weapon Type as key
		WEAPON_DEFS = new Dictionary<WeaponType, WeaponDefinition>();
		foreach(WeaponDefinition wd in weaponDefinitions) 
		{
			WEAPON_DEFS[wd.type] = wd;
		}
	}


	void Start(){
		//init start time
		startTime = Time.time;
		activeWeaponTypes = new WeaponType[weaponDefinitions.Length];
		for(int i = 0; i < weaponDefinitions.Length; i++)
		{
			activeWeaponTypes[i] = weaponDefinitions[i].type;
		}

		//Update score and lives
		UpdateScore();
		UpdateLives();
		//boss is alive
		bossDefeated = false;
		//show level name
		enableLeveltext = true;
		//Spawn waves of enemies
		// Find player and deactivate while
		// the level text is displayed
		player = GameObject.FindGameObjectWithTag("Player");
		player.SetActive(false);
		Invoke("DisplayLevelText", 0); //Call the Display level text function
		if(SceneManager.GetActiveScene().buildIndex == 2)
			InvokeRepeating("SpawnAsteroid",4f, 3.5f);
	}

	//Called each frame
	void Update()
	{
		//Update timer
		timer = Time.time - startTime;
		//Update score and lives
		UpdateScore();
		UpdateLives();

		//If the game over screen/text is active 
		//Continue at the last stage
		if(texts[2].gameObject.activeSelf)
		{
			if(Input.GetKey(KeyCode.Return))
			{
				//reset lives and score
				playerLives = 3;
				score = 0;
				Restart();
			}

			//Return to titlescreen if player press the escape key
			if(Input.GetKey(KeyCode.Escape)){
				//reset lives and score
				playerLives = 3;
				score = 0;
				SceneManager.LoadScene(0);
			}
		}

		//If the level boss has been defeated
		if(bossDefeated)
		{
			bossDefeated = false;

			if(player.activeInHierarchy) 
			{ //If the player is still alive
				CancelInvoke(); //Cancel the enemy spawning invokation
				Invoke("ChangeScene", 2f); //Load next scene

			}
		}

		//print(timer);
	}

	//Get the active scene's build index and increment it
	// and load the next scene in the build.
	void ChangeScene()
	{
		int sceneIndex = SceneManager.GetActiveScene().buildIndex;
		SceneManager.LoadScene(++sceneIndex);	
	}

	//Sets the boolean variable 
	public void EnableBossDefeated()
	{
		bossDefeated = true;
	} 


	//Spawns asteroids for level two
	public void SpawnAsteroid()
	{
		//If the boss is active return

		if(GameObject.FindObjectOfType<EnemyG>())
			return;
		//pick spawnPosition
		spawnPos = getSpawnPos();
		GameObject asteroid = Instantiate(enemyPrefabs[Random.Range(1,3)]);
		asteroid.transform.position = spawnPos;
	}


	//Spawn waves of enemies
	public void SpawnWave()
	{
		//if no prefabs are in the array
		//end function
		if(enemyPrefabs.Count == 0)
		{
			return;
		}

		//if any of the bosses are active return
		if(FindObjectOfType<EnemyE>()!= null || FindObjectOfType<EnemyG>()!= null){
			//Invoke("SpawnWave",waveTime);
			return;
		}

		//The enemies to be spawned varies with the active level and how much time has passed 
		// on the timer.
		if (timer < 30f){
			if (SceneManager.GetActiveScene().buildIndex == 1) //Level two has a different spawnrange
				index = Random.Range(1,2);
			if(SceneManager.GetActiveScene().buildIndex == 2)
				index = Random.Range(1,enemyPrefabs.Count);
			if(SceneManager.GetActiveScene().buildIndex == 3)
				index = Random.Range(1,4);
		}
		
		if (timer > 30f  && timer < 80f)
		{
			if (SceneManager.GetActiveScene().buildIndex == 1)
				index = Random.Range(1,enemyPrefabs.Count);
			if (SceneManager.GetActiveScene().buildIndex == 2) //Level two has a different spawnrange
				index = Random.Range(4,6);
			if(SceneManager.GetActiveScene().buildIndex == 3) //Last level throws any kind of enemy 
				index = Random.Range(1,enemyPrefabs.Count);
		}
	
		if (timer > 90) //Spawn boss
			index = 0; 	

		//Pick enemy to spawn
		
		//pick spawnPosition
		spawnPos = getSpawnPos();
		GameObject enemy = Instantiate(enemyPrefabs[index]);
		 
		//Check the first enemys name and create enemy formations 
		// if it is of enemey types that are supposed to appear in 
		// formations.
		if(enemy.name.Contains("EnemyA") || enemy.name.Contains("EnemyB")){
			//Setpostion for the first enemy in the line
			enemy.transform.position = spawnPos;

			//Create more enemies of the same type and alter their y-pos
			//to make them form a column
			if(Random.value < 0.5f)
			for (int i = 0; i < 4; i++)
				{
					GameObject e = Instantiate(enemyPrefabs[index]);
					spawnPos.y += offset; //Make space between the spawned enemies
					e.transform.position = spawnPos;
					e.GetComponent<Enemy>().SetFireRate();
			}
			else{
			//Spawn enemies in a row on the x-axis
			// Get the x-position of the first enemy so
			// we can spawn the rest beside it depending of the position of it.
			float posX = spawnPos.x;
			for (int i = 0; i < 4; i++){
				GameObject e = Instantiate(enemyPrefabs[index]);
				//If the first enemy is placed on the left side of the screen
				// ( posX < 0) place the rest on the right side of it else 
				// put them on the oppsite side
				if(posX< 0)
					spawnPos.x += offset; //Make space between the spawned enemies
				else
					spawnPos.x -= offset; //Make space between the spawned enemies
				e.transform.position = spawnPos;
				e.GetComponent<Enemy>().SetFireRate();
			}
			}
		}
		else //Spawn single enemy at spawnPos
			enemy.transform.position = spawnPos;

		Invoke("SpawnWave",waveTime);
	}
		

	//Function returns a vector3 with the spawnPosition
	public Vector3 getSpawnPos()
	{
		Vector3 temp = Vector3.zero;
		temp.x = Random.Range(boundary.xMin, boundary.xMax);
		temp.y = boundary.yMax - yMaxOffset;
		return temp;
	}

	//Invoke Restart function delayForSeconds after player death
	public void DelayRestart(float delayForSeconds)
	{
		//decrease player lives 
		playerLives--;
		if(playerLives > 0)
			Invoke("Restart", delayForSeconds);
		else
			texts[2].gameObject.SetActive(true);
	}

	//Restart level
	public void Restart(){
		//Reload level
		//string s = SceneManager.GetActiveScene().buildIndex;
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
	}


	//Check if the key exists in dictionary, if so, retreive it. Otherwise 
	// return the definition with type "none"
	static public WeaponDefinition GetWeaponDefinition (WeaponType wt)
	{
		if(WEAPON_DEFS.ContainsKey(wt)){
			
			return (WEAPON_DEFS[wt]);
		}
		return(new WeaponDefinition());
	}

	//Function to generate powerups when enemies are destroyed
	public void EnemyDestroyed(Enemy enemy)
	{
		score += enemy.GetScore();
		if(score % 10000 == 0 )
			playerLives++;
		//Randomize a value between 0 and 1 
		if(Random.value <= enemy.powerupDropProbability){

			//Choose powerup
			int idx = Random.Range(0, powerUpFrequency.Length);
			WeaponType powerUpType = powerUpFrequency[idx];
		
			//Spawn a powerup
			GameObject gObj = Instantiate(powerupPrefab) as GameObject;
			PowerUp pUp = gObj.GetComponent<PowerUp>();
			pUp.SetType(powerUpType);

			//Put the powerup at the enemys position 
			pUp.transform.position = enemy.transform.position;
		}
	} 

	//Updates the score text
	void UpdateScore()
	{
		texts[0].text = "SCORE " + score;
	}

	//Updates the lives text
	void UpdateLives()
	{
		texts[1].text = "LIVES " + playerLives;
	}

	//Displays the levelname on screen
	void DisplayLevelText()
	{
		
		if(enableLeveltext){
			texts[3].text = "LEVEL " + SceneManager.GetActiveScene().buildIndex;
			texts[3].gameObject.SetActive(true);
		}
		else{
			texts[3].gameObject.SetActive(false);
			if(player)
				player.SetActive(true);
			Invoke("SpawnWave", 4f);
		}

		if (enableLeveltext) 
			Invoke("DisplayLevelText", 3f); //Call this function again 

		enableLeveltext = false; //disables text on next call 

	}
}

