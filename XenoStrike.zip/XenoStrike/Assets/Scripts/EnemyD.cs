﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//A enemey that stays at the top of the screen and fires at the player
// it moves along a Bezier curve, a linear interpolation between more than two points
public class EnemyD : Enemy {

	public Vector3[] points;
	public float birthTime;
	public float lifeTime = 10;
	public float padding = 5;

	// Use this for initialization
	void Start () {

		//initialize points 
		points = new Vector3[3];
		//Startpoint is set by gamcontroller
		points[0] = pos;

		//Vector to set the other points
		Vector3 vec = Vector3.zero;

		//Pick a random position at lower half of screen
		vec.x = Random.Range(boundary.xMin+padding,boundary.xMax-padding);
		vec.y = Random.Range(0, boundary.yMin);
		points[1]=vec;

		//pick a random final position above the screen 
		vec.x = Random.Range(boundary.xMin+padding,boundary.xMax-padding);
		vec.y = pos.y;
		points[2]=vec;

		//Birthtime is set to current time.
		birthTime= Time.time;

		//Fire guns
		InvokeRepeating("Fire", 1f, fireRate);
	}

	
	public override void Move ()
	{
		//Bezier curve work based on a value u between 0 and 1
		float u = (Time.time - birthTime )/ lifeTime;
		//if u gets over one destroy this enemy
		if(u>1)
		{
			Destroy(this.gameObject);
			return;
		}

		//Interpolate between the three Bezier curve points.
		Vector3 point01, point12;
		u = u - 0.2f * Mathf.Sin( u * Mathf.PI * 2 );
		point01 = (1-u) * points[0] + u * points[1]; 
		point12 = (1-u) * points[0] + u * points[2]; 
		pos = (1-u) * point01 + u * point12;
	}
}
