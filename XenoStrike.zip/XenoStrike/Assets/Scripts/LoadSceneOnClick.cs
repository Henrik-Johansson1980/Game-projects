﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class LoadSceneOnClick : MonoBehaviour {

	//Loads the scene located at this index
	public void LoadByIndex(int sceneIdx)
	{
		SceneManager.LoadScene(sceneIdx);
	}
}
