﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//class that represents the boundary of a gameobject
//so we can destroy / deactivate it if out of bounds
[System.Serializable]
public class Boundary{
	public float xMin, xMax,yMin,yMax;
}


//Class that represents the player
//Used to read inputs and describe the player ships movement
// and such
public class Player : MonoBehaviour {

	static public Player PLAYER; //Singleton 
	//Variables that control the ships movement
	public float speed = 30;
	public float rollMultiplier = -45;
	public float pitchMultiplier = 30;
	public Boundary boundary;
	public float respawnWait = 2f;
	public GameObject explosion;
	//Weapons 
	public Weapon[] weapons;
	//Delegate Type for firing weapons
	public delegate void WeaponFireDelegate();
	//Delegate field 
	public WeaponFireDelegate fireDelegate;

	//Set the player singleton
	void Awake(){
		PLAYER = this;
	}

	void Start()
	{
		//Reset the weponsarray so that the player starts with blaster
		ClearWeapons();
		weapons[0].SetType(WeaponType.blaster);

	}
				
	// Update is called once per frame
	void Update () {
		//Get information from input class
		float xAxis = Input.GetAxis("Horizontal");
		float yAxis = Input.GetAxis("Vertical");

		//Change the transforms position based on the x- and y-axis
		Vector3 newPos = transform.position;
		newPos.x += xAxis * speed * Time.deltaTime;
		newPos.y += yAxis * speed * Time.deltaTime;
		transform.position = newPos;
		//Rotate player ship 
		transform.rotation = Quaternion.Euler(yAxis*pitchMultiplier,xAxis*rollMultiplier, 0);
		//Keep ship within bounds
		clampPosition();

		//Using the fire  delegate to fire weapons
		//This uses the Axis "Jump" button (spacebar)
		if (Input.GetButton("Jump") && fireDelegate != null)
		{
			fireDelegate();
		}
	}


	//Locks the player within the x. and y-coordinates of boundary
	void clampPosition(){
		transform.position = new Vector3(
			Mathf.Clamp(transform.position.x, boundary.xMin, boundary.xMax),
			Mathf.Clamp(transform.position.y, boundary.yMin, boundary.yMax),
			0f //z-axis
		);
	}

	//Check for collisions with other gameobjects
	// Destroy player and the colliding object
	void OnTriggerEnter(Collider other)
	{
		//Check if the player collided with enemis or enemy bullets
		if(other.CompareTag("Enemy")||other.CompareTag("EnemyProjectile"))
		{
			Destroy(other.gameObject); //Destroy the colliding object
			Instantiate(explosion, this.transform.position, this.transform.rotation);
			Destroy(this.gameObject); //Destroy this object
			GameController.GAMECONTROLLER.DelayRestart(respawnWait); //Restart level after respawnWait seconds
		}
		//Collider was powerup
		else if (other.CompareTag("PowerUp"))
		{
			CollectPowerUp(other.gameObject);
		}
			
	} 

	//Function for collecting power ups
	public void CollectPowerUp(GameObject obj)
	{
		PowerUp powerUp = obj.GetComponent<PowerUp>();
		//Check for type of powerup
		switch (powerUp.type)
		{
			//case shield... not implemented

			//if it is a kind of weapon 
			default: 
				if(powerUp.type == weapons[0].type)
				{
					//Increase number of weapons of this type
					Weapon weapon = GetEmptyWeaponSlot(); //Find available weaponslot
					if(weapon != null)
					{
						//set it to powerup type
						weapon.SetType(powerUp.type);
					}
				} else
				{
					ClearWeapons();
					weapons[0].SetType(powerUp.type); //set the weapon to be of the type of the powerup
				}
			break;
		}
		powerUp.CollectedBy(this.gameObject);
	}

	//returns an empty weaponslot
	Weapon GetEmptyWeaponSlot()
	{
		for(int i = 0; i < weapons.Length; i++)
		{
			if(weapons[i].type == WeaponType.none)
				return (weapons[i]);
		}
		return null;
	}

	//Resets the weapontypes in weapons to be of type WeaponType.none
	void ClearWeapons()
	{
		foreach(Weapon w in weapons)
		{
			w.SetType(WeaponType.none);
		}
	}
}
