﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Various possible weapontypes
public enum WeaponType
{
	none, //Default
	blaster, //Single shot blaster
	spread, //Multiple shots
	rapid, //Increased fireRate
}

//Make it possible to view WeaponDefinitions in inspector
[System.Serializable]
public class WeaponDefinition
{
	public WeaponType  type = WeaponType.none;
	public string pUpLetter;  //Letter on powerup
	public Color color = Color.white;
	public GameObject projectilePrefab;
	public Color projectileColor = Color.white;
	public float damage = 0; //Damage made per shot
	public float continuosDamage = 0; //Damage per second for a laser type weapon 
	public float shotDelay = 0; //Cooldown between shots
	public float shotVelocity = 20; //Speed of projectile
}


public class Weapon : MonoBehaviour {

	static public Transform projectileStartLocation;

	[SerializeField]
	private WeaponType _type =  WeaponType.blaster;
	public WeaponDefinition wDef; 
	public GameObject muzzle;
	public float lastShot; //Time when last fire was fired

	void Awake()
	{
		//find the gun muzzle
		muzzle = transform.Find("Muzzle").gameObject;
	}

	void Start()
	{
		//set the weapon type 
		SetType(_type);

		if(projectileStartLocation == null){
			GameObject go = new GameObject("ProjectileStartLocation");
			projectileStartLocation = go.transform;
		}

		//Find the fireDelegate of parent
		GameObject weaponsParent = transform.parent.gameObject;
		if(weaponsParent.tag == "Player")
			Player.PLAYER.fireDelegate += Fire;
	}


	public WeaponType type 
	{
		get {return (_type);}
		set {SetType(value);}
	}

	//set the type of weapon and activate the gun
	public void SetType (WeaponType wt)
	{
		_type = wt;

		//Deactivate weapon if type is set to none
		if(type == WeaponType.none){
			this.gameObject.SetActive(false);
			return;
		} 
		else  //Activate weaponobject
		{
			this.gameObject.SetActive(true);	
		}
		wDef = GameController.GetWeaponDefinition(_type); //get weapon definition
		muzzle.GetComponent<Renderer>().material.color = wDef.color; //Set the muzzle color to indidicate what weapon is active
		lastShot = 0; //No time delay on a newly activaded weapon
	}
		
	//Fire weapon
	public void Fire()
	{
		//If gameobject is inactive
		if(!gameObject.activeInHierarchy)
			return;
		//If enough time has not passed since last shot
		if(Time.time - lastShot < wDef.shotDelay)
			return;
		Projectile projectile;

		switch(type)
		{
		//Shoot straight forward
		case WeaponType.blaster:
			projectile = CreateProjectile();
			projectile.GetComponent<Rigidbody>().velocity = Vector3.up * wDef.shotVelocity; //multiply The vector with the weapons velocity value
			break;
		
		//Each gun fires three bullets
		case WeaponType.spread:
			projectile = CreateProjectile();
			projectile.GetComponent<Rigidbody>().velocity = Vector3.up * wDef.shotVelocity;
			projectile = CreateProjectile();
			projectile.GetComponent<Rigidbody>().velocity = new Vector3(-.2f, 0.9f, 0) * wDef.shotVelocity; //Angle bullet to the left
			projectile = CreateProjectile();
			projectile.GetComponent<Rigidbody>().velocity = new Vector3(.2f, 0.9f, 0) * wDef.shotVelocity;	//Angle bullet to the right
			break;
		//Shoot straight forward
		case WeaponType.rapid:
			projectile = CreateProjectile();
			projectile.GetComponent<Rigidbody>().velocity = Vector3.up * wDef.shotVelocity;
			break;
		}
	}

	//Creates a projectile 
	public Projectile CreateProjectile()
	{
		GameObject projectile = Instantiate(wDef.projectilePrefab) as GameObject;
		//if the player is the parent make tag it as a player projectile
		if(transform.parent.gameObject.tag == ("Player"))
		{
			projectile.tag = "PlayerProjectile"; //Assign tag
			projectile.layer = LayerMask.NameToLayer("PlayerProjectile"); //Assign layer
		} 
		else //Not implemented in this game  
		{
			//projectile.tag = "EnemyProjectile";
			//projectile.layer = LayerMask.NameToLayer("EnemyProjectile");
		}

		//Set the position to the gunmuzzle påosition
		projectile.transform.position = muzzle.transform.position; 
		projectile.transform.parent = projectileStartLocation; //Set p
		Projectile p = projectile.GetComponent<Projectile>(); 
		p.type = _type; //sets the weapontype that fires teh bullet
		lastShot = Time.time; //last time the weapon fired
	
		Player.PLAYER.GetComponent<AudioSource>().Play(); //Play the Audiosource attatched to the player
		return p;
	}
}
