﻿using UnityEngine;
using System.Collections;

public class Timer : MonoBehaviour {
	static public float time;

	// Use this for initialization
	void Start () {

		//Överlev i ett visst antal sekunder per level.

		if(Application.loadedLevelName == "Level1")
			time = 30;	
		
		if(Application.loadedLevelName == "Level2")
			time = 45;
		
		if(Application.loadedLevelName == "Level3")
			time = 75;

		GetComponent<GUIText>().text = "Time: " + time.ToString("00"); 
	}
	
	// Update is called once per frame
	void Update () {
		//Räkna ned tiden om spelaren inte är död
		if(!(ExplodeOnTrigger.isDead == true)) //Kontrollera värdet på variabeln isDead i ExplodeOnTriggerscriptet.
		{
			time -= Time.deltaTime;
			GetComponent<GUIText>().text = "Time: " + time.ToString("00");
		}
		if(time <= 0 )
		{
			//Om tiden är mindre än eller liga med noll skriv bara tiden 00
			GetComponent<GUIText>().text = "Time: 00";

		}
	
	}

}
