﻿using UnityEngine;
using System.Collections;

public class ToCredits : MonoBehaviour {
	
	// Update is called once per frame
	void Update () {
		//Om valfri tangent trycks ned starta leveln Credits
		if(Input.anyKeyDown)
			Application.LoadLevel("Credits");
	}
}
