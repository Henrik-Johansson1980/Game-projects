﻿using UnityEngine;
using System.Collections;

public class QuitGame : MonoBehaviour {

	// Update is called once per frame
	void Update () {
		//Stäng applikationen när en tangent trycks ned
		if(Input.anyKeyDown)
			Application.Quit();
	}
}
