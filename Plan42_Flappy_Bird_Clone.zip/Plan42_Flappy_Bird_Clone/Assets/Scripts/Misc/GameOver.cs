﻿using UnityEngine;
using System.Collections;

public class GameOver : MonoBehaviour {

	public GameObject ufo;

	void Start()
	{
		//Kontrollera om godmode är påslaget i scriptet ExplodeOnTrigger
		if(ExplodeOnTrigger.godMode)
			ExplodeOnTrigger.godMode = false;
	}

	// Update is called once per frame
	void Update () {
		//Om spelaren är död
		if(ExplodeOnTrigger.isDead == true)
		{
			GetComponent<GUIText>().text = "Game Over\nTry Again (Y/N)?";
			if(Input.GetKeyDown(KeyCode.Y))
			{
				ExplodeOnTrigger.isDead = false;
				Application.LoadLevel(Application.loadedLevel);
			}
			else if (Input.GetKeyDown(KeyCode.N))
				Application.LoadLevel("Credits");
		}
		else
			GetComponent<GUIText>().text = "";

		if (Timer.time <= 0)
		{
			ExplodeOnTrigger.godMode = true; //Starta godmode
			ufo.GetComponent<Rigidbody>().isKinematic = true; //Stäng av gravitationen

			//På sista banan (level3)
			if(Application.loadedLevelName == "Level3")
			{
				GetComponent<GUIText>().text = "You did it!\nPress a key to continue";
				if (Input.anyKeyDown)
				{
					if(Application.loadedLevelName == "Level3")
						Application.LoadLevel("GameOverScreen");
				}

			}
			else
			// På bana ett och två
			GetComponent<GUIText>().text = "Stage Clear!\nPress a key to\ncontinue to the next level";
			if (Input.anyKeyDown)
			{
				if(Application.loadedLevelName == "Level1")
					Application.LoadLevel("Level2");

				if(Application.loadedLevelName == "Level2")
					Application.LoadLevel("Level3");
			}
		}
	}
}
