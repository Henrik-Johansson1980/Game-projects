﻿using UnityEngine;
using System.Collections;

public class ClearObstaclesScript : MonoBehaviour {
	
	void OnTriggerEnter()
	{
		//Förstör object med tagg Obstacle
		Destroy(GameObject.FindGameObjectWithTag("Obstacle"));
	}
}