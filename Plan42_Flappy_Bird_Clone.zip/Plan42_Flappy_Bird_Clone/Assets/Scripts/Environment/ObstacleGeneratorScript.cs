﻿using UnityEngine;
using System.Collections;

public class ObstacleGeneratorScript: MonoBehaviour {

	public GameObject obstacle;
	public float spawnTime = 1.7f;
	// Use this for initialization
	void Start () 
	{
		//Anropar metoden Create Obstacle efter 0.1 sekunder och därefter en gång per spawnTime sekunder.
		InvokeRepeating("CreateObstacle", 0.1f , spawnTime); 
	}
		void CreateObstacle()
		{
			Instantiate(obstacle); //Instantiera ett spelobjekt av typen obstacle
		}
}	
