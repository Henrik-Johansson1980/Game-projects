﻿using UnityEngine;
using System.Collections;

public class BGScroller : MonoBehaviour {
	
	// Update is called once per frame
	void Update () 
	{
		//Scrolla bakgrunden
		MeshRenderer meshrenderer = GetComponent<MeshRenderer>();
		Material material = meshrenderer.material;
		Vector2 offset = material.mainTextureOffset;
		offset.x += Time.deltaTime / 10;
		material.mainTextureOffset = offset;
	}
}
