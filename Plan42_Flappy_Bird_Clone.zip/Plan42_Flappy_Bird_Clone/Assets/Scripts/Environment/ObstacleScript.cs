﻿using UnityEngine;
using System.Collections;

public class ObstacleScript : MonoBehaviour {

	public Vector3 obstacleVelocity = new Vector3 (-10f ,0,0 ); //Utsätt varje hinder för en kraft som för det 
																// åt vänster över skärmen
	GameObject obstacle;
	public float obstacleMax = 6.5f;	//Maxförskjutning i höjdled
	public float obstacleMin = -3.5f;	//Minförskjutning i höjdled

	// Use this for initialization
	void Start () {
		GetComponent<Rigidbody>().velocity = obstacleVelocity;
		transform.position = new Vector3(transform.position.x, 
		                     transform.position.y + Random.Range(obstacleMin,obstacleMax),transform.position.z);
	}
}
