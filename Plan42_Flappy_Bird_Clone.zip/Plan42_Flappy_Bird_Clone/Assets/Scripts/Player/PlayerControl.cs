﻿using UnityEngine;
using System.Collections;

public class PlayerControl : MonoBehaviour {

	Rigidbody rb; 
	public ParticleSystem burst; 
	public Vector3 forceUp = new Vector3();
	bool goUp = false;


	// Use this for initialization
	void Start () {
		//Hämta en Rigidbody
		rb = GetComponent<Rigidbody>();
		transform.rotation = Quaternion.Euler(270,270,0); //Vrid ufot åt rätt håll på skärmen.
	}
	
	// Update is called once per frame
	void Update () {
		//Kontrollera skeppet
		if(Input.GetKeyDown(KeyCode.Space)|| Input.GetMouseButtonDown(0))
		{
			goUp = true; //Skeppet stiger
			burst.Play(); // Spela partikelsystemet
			AudioSource boost = GetComponent<AudioSource>();
			boost.Play ();//Spela ljudklipp vid boost
		}

	}

	void FixedUpdate()
	{
		if(goUp)
		{	goUp = false; //Skeppet faller
			rb.velocity = Vector3.zero; //vector 3 med alla argument = 0
			rb.AddForce(forceUp); //Utsätt spelaren (ufot) för en kraft uppåt.
			burst.Stop(); //Stänga av partikelsystem 
		}

		//Vrid skeppet om det störtar/stiger
		if (rb.velocity.y > 0)
		{
			transform.rotation = Quaternion.Euler (269,270,0);
		}
		else
		{	float angle = Mathf.Lerp(270,-90,-rb.velocity.y /75 );
			transform.rotation = Quaternion.Euler(angle,angle,0); 
		}
	}
}
