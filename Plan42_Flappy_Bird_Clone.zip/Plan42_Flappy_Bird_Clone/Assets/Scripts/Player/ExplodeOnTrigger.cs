﻿using UnityEngine;
using System.Collections;

public class ExplodeOnTrigger : MonoBehaviour {

	public GameObject gib; //Gib är en förkorting av giblets dvs. partiklar av ett förstört objekt i detta fall en 
							// partikelsystem "explosion".
	static public bool godMode = false; //Variabel som sätter på/av odödlighet används av andra script
	static public bool isDead = false;	// Variabel som används för att kontrollera om spelaren lever, används av andra script.

	void OnTriggerEnter(Collider other)
	{
		if (godMode){
			return; // Om godmode är på ignorera kollisioner
		}
		//Om inte ojectet har taggen Point, spela partikelexplosion
		if(!(other.tag == "Point"))
		{					
			isDead = true;
			if (gib  != null)
			{
				Instantiate(gib,transform.position,gib.transform.rotation); //Skapa explosion
			}
			gameObject.SetActive(false); //Inaktivera ufot
		}
	}
}
