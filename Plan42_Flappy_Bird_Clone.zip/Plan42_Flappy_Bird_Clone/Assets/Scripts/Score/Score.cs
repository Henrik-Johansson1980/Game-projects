﻿using UnityEngine;
using System.Collections;

public class Score : MonoBehaviour {

	static int score = 0;
	static int tmpScore = 0;
	static int highScore = 0 ;

	void Start(){

		//Läs in lagrad highscore
		highScore = PlayerPrefs.GetInt("HighScore", 0);

		if(Application.loadedLevelName == "Level1")
			score = 0; 


		if(Application.loadedLevelName == "Level2")
			score = tmpScore; // För över poängen från föregående level
		
		if(Application.loadedLevelName == "Level3")
			score = tmpScore; // För över poängen från föregående level
	}

	// Update is called once per frame
	void Update () {
		GetComponent<GUIText>().text = "High Score: " + highScore + "\nScore: " + score;

		if (ExplodeOnTrigger.isDead)
		{
			tmpScore = 0; // Omspelaren dör nollställ poängen
		}
	}

	static public void AddPoint()
	{
		score += 100; //Hundra poäng per passerat hinder
		tmpScore = score; //Lagra poäng till nästa level 
		
		if(score > highScore) // om poängen är högre än higscore 
		{
			highScore = score; // Ny highscore
		}
	}

	void OnDestroy() {
		PlayerPrefs.SetInt("HighScore", highScore); // Spara highscore mellan spel
	}


}
