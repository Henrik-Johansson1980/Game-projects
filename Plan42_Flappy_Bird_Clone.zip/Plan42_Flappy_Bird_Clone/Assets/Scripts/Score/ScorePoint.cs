﻿using UnityEngine;
using System.Collections;

public class ScorePoint : MonoBehaviour {

	void OnTriggerEnter(Collider collider)
	{	
		if(ExplodeOnTrigger.godMode) 	//Stäng av kollisioner om god mode är aktivt
			return;						//Annars fortsätter poängen att ticka när spelaren är fryst.
	
		if (collider.tag == "Player")
		{
			Score.AddPoint();				//Anropa funktionen Addpoint från scorescriptet
			gameObject.SetActive(false);	// Inaktivera spelobjektet (ScoreBox)när spelaren träffat
		}
	}
}
